package application;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import database.DBSelect;
import structures.DBEdge;
import structures.DBFile;
import structures.DBGraph;
import structures.DBNode;

public class Exporter
{
	private ArrayList<DBNode> nodes = new ArrayList<DBNode>();
	private ArrayList<DBFile> files = new ArrayList<DBFile>();
	private ArrayList<DBEdge> edges = new ArrayList<DBEdge>();
	
	private Document document = new Document();
	
	private Font titleFont = FontFactory.getFont(FontFactory.HELVETICA, 18, BaseColor.BLACK);
	private Font regFont = FontFactory.getFont(FontFactory.HELVETICA, 12, BaseColor.BLACK);
	
	private PdfPTable table = new PdfPTable(3);
	
	public Exporter()
	{
		
	}
	
	public void compilePDF(String gid, String nid)
	{
		DBGraph graph = DBSelect.selectGraph(gid);
		
		try
		{
			PdfWriter.getInstance(document, new FileOutputStream("export/" + graph.label + ".pdf"));
			
			document.open();
			
			DBNode startNode = findNode(nid);
			addNode(startNode);
			document.add(table);
			

			document.close();
		} 
		catch (FileNotFoundException | DocumentException e)
		{
			e.printStackTrace();
		}
	}
	
	private void addNode(DBNode node) throws DocumentException
	{
		BaseColor col = new BaseColor(node.colour.red(), node.colour.green(), node.colour.blue());
		Font font = FontFactory.getFont(FontFactory.HELVETICA, 14, col);
		
		Chunk chunk = new Chunk(node.label, font);
		document.add(chunk);
		
		PdfPCell cell = new PdfPCell();
		cell.addElement(chunk);
		
		table.addCell("");
		table.addCell("");
		
		if (node.description.length() > 0)
		{
			Paragraph desc = new Paragraph(node.description, regFont);
			PdfPCell dcell = new PdfPCell();
			dcell.addElement(desc);
			table.addCell("");
			table.addCell(dcell);
		}
	}
	
	private void findNextNode(String nid)
	{
		
	}
	
	public void addNodes(ArrayList<DBNode> nodes)
	{
		this.nodes.addAll(nodes);
	}
	
	public void addFiles(ArrayList<DBFile> files)
	{
		this.files.addAll(files);
	}
	
	public void addEdges(ArrayList<DBEdge> edges)
	{
		this.edges.addAll(edges);
	}
	
	private DBNode findNode(String nid)
	{
		for (DBNode n : nodes)
		{
			if (n.nid.equals(nid))
				return n;
		}
		
		return null;
	}

}
