package application;

import java.util.ArrayList;
import java.util.HashMap;

import database.DBDelete;
import database.DBInsert;
import database.DBSelect;
import database.DBUpdate;
import universal.CodeLogger;
import universal.CodeLogger.DEPTH;

public class Settings
{
	public static HashMap<Key, String> settings = new HashMap<Key, String>();
	public static ArrayList<String> images = new ArrayList<String>();
	public static ArrayList<String> documents = new ArrayList<String>();
		
	public Settings()
	{
		images.add("png"); images.add("jpg"); images.add("jpeg"); images.add("gif");
		documents.add("doc"); documents.add("docx"); documents.add("txt"); documents.add("pdf");
		
		DBSelect.loadSettings();
		
		if (!settings.keySet().contains(Key.FILE_REPO))
			DBInsert.insertSetting(Key.FILE_REPO.toString(), "");
		
		if (!settings.keySet().contains(Key.NOTES_VISIBLE))
			DBInsert.insertSetting(Key.NOTES_VISIBLE.toString(), "true");
		
		if (!settings.keySet().contains(Key.GRAPH_PADDING))
			DBInsert.insertSetting(Key.GRAPH_PADDING.toString(), "50");
		
		if (!settings.keySet().contains(Key.TEXT_SIZE))
			DBInsert.insertSetting(Key.TEXT_SIZE.toString(), "12");
		
		if (!settings.keySet().contains(Key.NODE_SIZE))
			DBInsert.insertSetting(Key.NODE_SIZE.toString(), "30");
		
		if (!settings.keySet().contains(Key.EDGE_SIZE))
			DBInsert.insertSetting(Key.EDGE_SIZE.toString(), "1");
		
		if (!settings.keySet().contains(Key.EDGE_LENGTH))
			DBInsert.insertSetting(Key.EDGE_LENGTH.toString(), "1");
	}
	
	public static enum Key
	{
		FILE_REPO,
		NOTES_VISIBLE,
		GRAPH_PADDING,
		TEXT_SIZE,
		NODE_SIZE,
		EDGE_SIZE,
		EDGE_LENGTH
		
	}
	
	public static void set(Key key, Object s)
	{
		String str = String.valueOf(s);
		
		if (!settings.get(key).equals(str))
		{
			settings.put(key, str);
			DBUpdate.updateSettings(key.toString(), str);
		}
	}
	
	public static String get(Key key)
	{
		return settings.get(key);
	}
	
	public static double getFloat(Key key)
	{
		return Double.valueOf(settings.get(key));
	}
	
	public static int getInt(Key key)
	{
		return Integer.valueOf(settings.get(key));
	}
	
	public static boolean getBool(Key key)
	{
		return Boolean.valueOf(settings.get(key));
	}
	
	public static Key mapKey(String key)
	{
		for (Key k : Key.values())
		{
			if (k.toString().equals(key))
				return k;
		}
		
		CodeLogger.err("No Key", DEPTH.ROOT);
		return null;
	}
	
}
