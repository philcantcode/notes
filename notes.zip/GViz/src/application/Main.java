package application;
	
import database.DBDelete;
import database.DBInsert;
import database.DBSelect;
import database.DBUpdate;
import database.Database;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import structures.ShapeIcon;

public class Main extends Application 
{	
	public static Stage stageLink = null;
	
	@Override
	public void start(Stage stage) 
	{
		System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");
		
		new Database();
		new DBInsert();
		new DBSelect();
		new DBUpdate();
		new DBDelete();
		new Settings();
		new Utils();
		new ShapeIcon();
		
		try {
			
			Parent display = FXMLLoader.load(getClass().getResource("/gui/Display.fxml"));
			Scene scene = new Scene(display, 800, 600);
			scene.getStylesheets().add("gui/darkMode.css");
			stage.setTitle("Graph Display");
	        stage.setScene(scene);
	        stage.setMinHeight(600);
	        stage.setMinWidth(800);
	        
	        stage.setOnCloseRequest(new EventHandler<WindowEvent>() 
	        {
	            @Override
	            public void handle(WindowEvent t) {
	                Platform.exit();
	                System.exit(0);
	            }
	        });
	        
	        stageLink = stage;
	        stage.show();
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) 
	{
		launch(args);
	}
}
