package structures;

public class DBNode
{
	public String nid = null;
	public String gid = null;
	public String label = null;
	public String description = null;
	public FXColour colour = null;
	public String shape = null;
	public String icon = null;
		
	public DBNode(String nid, String gid, String label, String desc, FXColour colour, String shape, String icon)
	{
		this.nid = nid;
		this.gid = gid;
		this.label = label;
		this.description = desc;
		this.colour = colour;
		this.shape = shape;
		this.icon = icon;	
	}

}
