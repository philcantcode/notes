package structures;

import application.Settings;
import database.DBSelect;

public class DBFile
{
	public String hash = null;
	public FileType type = null;
	public String path = null;
	public DBNode node = null;
	
	public DBFile(String fid, String gid, String path, String hash, FileType type)
	{				
		this.path = path;
		this.hash = hash;
		this.type = type;
		
		node = DBSelect.selectNode(fid);			
	}
	
	public enum FileType
	{
		Image,
		Document,
		Web
	}
	
	public static FileType classifyType(String path)
	{
		String ext = path.substring(path.lastIndexOf(".") + 1, path.length()).toLowerCase();
		
		if (Settings.documents.contains(ext))
		{
			return FileType.Document;
		}
		else if (Settings.images.contains(ext))
		{
			return FileType.Image;
		}
		else
		{
			return FileType.Document;
		}
	}
	
	public static FileType getType(String type)
	{
		for (FileType ft : FileType.values())
		{
			if (ft.toString().equals(type))
				return ft;
		}
		
		return null;
	}
}
