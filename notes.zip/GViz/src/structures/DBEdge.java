package structures;

public class DBEdge
{
	public String eid = null;
	public String gid = null;
	public String label = null;
	public String src = null;
	public String dst = null;
	
	public boolean deleted = false;
	
	public DBEdge(String eid, String gid, String label, String src, String dst)
	{
		this.eid = eid;
		this.gid = gid;
		this.label = label;
		this.src = src;
		this.dst = dst;
	}

}
