package structures;

import javafx.event.ActionEvent;

public class EventManager extends ActionEvent
{

	private static final long serialVersionUID = 1L;

	public EventManager()
	{
		System.out.println("ree");
	}

}
