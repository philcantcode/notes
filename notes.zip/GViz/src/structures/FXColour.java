package structures;

public class FXColour
{

	private javafx.scene.paint.Color fxColour = null;
	private java.awt.Color awtColour = null;
	
	public FXColour(javafx.scene.paint.Color col)
	{
		this.fxColour = col;
		this.awtColour = hexToRGB();
	}
	
	public FXColour(java.awt.Color col)
	{
		awtColour = col;
		fxColour =  javafx.scene.paint.Color.rgb(red(), green(), blue());
	}
	
	public FXColour(String rgbTxt)
	{
		String[] rgbPart = rgbTxt.split(",");
		
		awtColour = new java.awt.Color(
	            Integer.valueOf( rgbPart[0] ),
	            Integer.valueOf( rgbPart[1] ),
	            Integer.valueOf( rgbPart[2] ));
		
		fxColour = javafx.scene.paint.Color.rgb(red(), green(), blue());
	}
	
	private java.awt.Color hexToRGB() 
	{
		String colorStr = fxColour.toString().replace("0x", "#");
		
	    return new java.awt.Color(
	            Integer.valueOf( colorStr.substring( 1, 3 ), 16 ),
	            Integer.valueOf( colorStr.substring( 3, 5 ), 16 ),
	            Integer.valueOf( colorStr.substring( 5, 7 ), 16 ) );
	}
	
	public int red()
	{
		return awtColour.getRed();
	}
	
	public int green()
	{
		return awtColour.getGreen();
	}
	
	public int blue()
	{
		return awtColour.getBlue();
	}
	
	public String rgb()
	{
		return red() + "," + green() + "," + blue();
	}
	
	public javafx.scene.paint.Color fx()
	{
		return fxColour;
	}
}
