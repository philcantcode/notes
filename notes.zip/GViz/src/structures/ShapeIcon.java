package structures;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import universal.CodeLogger;
import universal.CodeLogger.DEPTH;

public class ShapeIcon
{
	private static LinkedHashMap<String, String> icons = new LinkedHashMap<String, String>();
	private static LinkedHashMap<String, String> shapes = new LinkedHashMap<String, String>();
	
	public ShapeIcon()
	{
		icons.put("Calendar", "calendar.png"); icons.put("Clock", "clock.png");
        icons.put("Document", "document.png"); icons.put("Error", "error.png"); icons.put("Folder", "folder.png");
        icons.put("Location", "location.png"); icons.put("User", "user.png"); icons.put("Graph", "graph.png");
        icons.put("Success", "success.png"); icons.put("Web", "internet.png");
        
        shapes.put("Circle", "circle"); shapes.put("Box", "box"); shapes.put("Diamond", "diamond");
	}
	
	public static String shapeDB(String shape)
	{
		if (shape.equals("None") || shape.equals("Shape"))
			return "Circle";
		
		if (shapes.containsKey(shape))
			return shape;
		
		for (String key : shapes.keySet())
		{
			if (shape.equals(shapes.get(key)))
			{
				return key;
			}
		}
		
		CodeLogger.err("Shape DB: " + shape, DEPTH.ROOT);
		return null;
	}
	
	public static String shapeGraph(String shape)
	{
		if (shape.equals("None") || shape.equals("Shape"))
			return "circle";
		
		if (shapes.containsKey(shape))
			return shapes.get(shape);
		
		CodeLogger.err("Shape Graph: " + shape, DEPTH.ROOT);
		return null;
	}
	
	public static String iconDB(String icon)
	{
		if (icon.equals("None") || icon.equals("Icon"))
			return "None";
		
		if (icons.containsKey(icon))
			return icon;
		
		for (String key : icons.keySet())
		{
			if (icon.equals(icons.get(key)))
			{
				return key;
			}
		}
		
		CodeLogger.err("Icon DB: " + icon, DEPTH.ROOT);
		return null;
	}
	
	public static String iconGraph(String icon)
	{
		if (icons.containsKey(icon))
			return icons.get(icon);
		
		return null;
	}
	
	public static ArrayList<String> menuIcons()
	{
		ArrayList<String> menu = new ArrayList<String>();
		
		for (String k : icons.keySet())
			menu.add(k);
		
		menu.add("None");
		return menu;
	}
	
	public static ArrayList<String> menuShapes()
	{
		ArrayList<String> menu = new ArrayList<String>();
		
		for (String k : shapes.keySet())
			menu.add(k);
		
		menu.add("None");
		return menu;
	}

}
