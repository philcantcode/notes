package structures;

public class DBGraph
{
	public String gid = null;
	public String label = null;
	public String notes = null;
	public String description = null;
	
	public DBGraph(String gid, String label, String notes, String description)
	{
		this.gid = gid;
		this.label = label;
		this.notes = notes;
		this.description = description;
	}

}
