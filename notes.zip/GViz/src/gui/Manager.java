package gui;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import org.apache.commons.io.FilenameUtils;

import application.Exporter;
import application.FileManager;
import application.Settings;
import application.Settings.Key;
import database.DBDelete;
import database.DBInsert;
import database.DBSelect;
import database.DBUpdate;
import database.Database;
import javafx.scene.paint.Color;
import structures.DBEdge;
import structures.DBFile;
import structures.DBGraph;
import structures.DBNode;
import structures.FXColour;
import structures.ShapeIcon;
import universal.CodeLogger;
import universal.CodeLogger.DEPTH;

public class Manager
{
	public String NID_IN_USE = null;
    public String GID_IN_USE = null;
    
    private Thread labelThread = null;
    private Thread descThread = null;
    private Thread linkThread = null;
    private Thread linkLabelThread = null;
    private Thread noteThread = null;
    
    private DisplayController view = null;
    
	public Manager(DisplayController controller)
	{
		this.view = controller;
	}
	
	public DBNode createNode(String label, String desc, Color colour, String shape, String icon)
	{
		if (label == null || label.length() == 0)
			return null;
		
		FXColour fxCol = new FXColour(colour);
			
		String nid = Database.createID(GID_IN_USE, label, null);
		DBNode node = new DBNode(nid, GID_IN_USE, label, desc, fxCol, shape, icon);
		DBInsert.insertNode(nid, GID_IN_USE, label, desc, fxCol.rgb(), shape, icon);
		
		return node;
	}
	
	public DBGraph createGraph(String label)
	{
		if (label == null || label.length() == 0)
			return null;
		
		String gid = Database.createID(label, null, null);
		DBGraph graph = new DBGraph(gid, label, "", "");	
		
		if (DBInsert.insertGraph(gid, label, ""))
		{
			GID_IN_USE = gid;
			return graph;
		}
		
		return null;
	}
	
	public String removeNode()
	{
		String nid = NID_IN_USE;
		
		if (nid != null)
		{
			DBDelete.deleteNode(nid, GID_IN_USE);
			DBDelete.deleteFile(nid, GID_IN_USE);
			DBDelete.deleteEdgeByLink(nid, GID_IN_USE);
			
			NID_IN_USE = null;
			
			return nid;
		}
		
		return null;
	}
	
	/** 
	 * shape = Database Ready Shape
	 * icon = Database Ready Icon
	 * */
	public void updateNode(String nid, String label, String desc, Color col, String shape, String icon)
	{
		DBUpdate.updateNode(nid, GID_IN_USE, label, desc, new FXColour(col).rgb(), ShapeIcon.shapeDB(shape), ShapeIcon.iconDB(icon));
	}
	
	public void deleteGraph()
	{
		DBDelete.deleteGraph(GID_IN_USE);
	}
	
	public DBFile createFile(File f)
	{
		String label = FilenameUtils.removeExtension(f.getName());
		String fid = Database.createID(GID_IN_USE, label, null);
		String hash = FileManager.getFileChecksum(f);
		String newPath = Settings.get(Key.FILE_REPO) + "/" + f.getName();
		
		DBInsert.insertNode(fid, GID_IN_USE, label, "", "0,0,0", "Box", "Document");
		DBInsert.insertFile(fid, GID_IN_USE, hash, DBFile.classifyType(f.getName()).toString(), newPath);
		
		DBFile file = new DBFile(fid, GID_IN_USE, newPath, hash, DBFile.FileType.Document);
		
		try
		{
			Files.copy(f.toPath(), new File(newPath).toPath(), StandardCopyOption.REPLACE_EXISTING);
			view.progress();
		} 
		catch (IOException e)
		{
			CodeLogger.err("File Repo Doesn't Exist, Needs Creating", DEPTH.ROOT);
		}
		
		return file;
	}
	
	public DBFile createURL(String url, String label)
	{
		String fid = Database.createID(GID_IN_USE, url, null);
		
		DBInsert.insertNode(fid, GID_IN_USE, label, "", "0,0,0", "Box", "Web");
		DBInsert.insertFile(fid, GID_IN_USE, "", DBFile.FileType.Web.toString(), url);
		
		return new DBFile(fid, GID_IN_USE, url, "", DBFile.FileType.Web);
		
	}
	
	public DBEdge toggleEdge(String srcNID, String dstNID, String label)
	{
		DBNode src = DBSelect.selectNode(srcNID);
    	DBNode dst = DBSelect.selectNode(dstNID);
    	String eid = Database.createID(GID_IN_USE, nidSplit(src.nid), nidSplit(dst.nid));
    	
    	DBEdge edge = new DBEdge(eid, GID_IN_USE, label, src.nid, dst.nid);
    	
    	if (DBSelect.selectEdge(eid) == null)
    	{
    		DBInsert.insertEdge(edge.eid, edge.gid, edge.label, edge.src, edge.dst);
    	}
    	else
    	{
    		DBDelete.deleteEdge(eid, GID_IN_USE);
    		edge.deleted = true;
    	}
    	
    	return edge;
	}
	
	public void importGraph(String label)
	{
		DBGraph g = DBSelect.selectGraphByLabel(label);
		
		for (DBNode n : DBSelect.loadNodes(g.gid))
		{
			n.nid = Database.createID(GID_IN_USE, nidSplit(n.nid), null);
			n.gid = GID_IN_USE;
			DBInsert.insertNode(n.nid, n.gid, n.label, n.description, n.colour.rgb(), n.shape, n.icon);
		}
		
		for (DBFile f : DBSelect.loadFiles(g.gid))
		{
			f.node.nid = Database.createID(GID_IN_USE, nidSplit(f.node.nid), null);
			f.node.gid = GID_IN_USE;
			DBInsert.insertFile(f.node.nid, f.node.gid, f.hash, f.type.toString(), f.path);
		}
		
		for (DBEdge e : DBSelect.loadEdges(g.gid))
		{
			e.eid = Database.createID(GID_IN_USE, nidSplit(e.src), nidSplit(e.dst));
			e.src = Database.createID(GID_IN_USE, nidSplit(e.src), null);
			e.dst = Database.createID(GID_IN_USE, nidSplit(e.dst), null);
			e.gid = GID_IN_USE;
			DBInsert.insertEdge(e.eid, e.gid, e.label, e.src, e.dst);
		}
	}

	public static String nidSplit(String nid)
	{
		return nid.split(":")[1];
	}
	
	public void labelCounter(String text)
	{		
		if (this.labelThread != null && this.labelThread.isAlive())
		{
			this.labelThread.interrupt();
		}
		
		Runnable runnable = new Runnable() 
		{
            @Override
            public void run() 
            {
            	if (Thread.interrupted() == false)
        		{
            		try {
						Thread.sleep(1000);
						DBUpdate.updateNodeVar(NID_IN_USE, GID_IN_USE, "label", text);
						view.progress();
					}  catch (InterruptedException e) { }
        		}
            }
        };
        
        this.labelThread = new Thread(runnable);
        this.labelThread.start();
	}
	
	public void descCounter(String text)
	{		
		if (this.descThread != null && this.descThread.isAlive())
		{
			this.descThread.interrupt();
		}
		
		Runnable runnable = new Runnable() 
		{
            @Override
            public void run() 
            {
            	if (Thread.interrupted() == false)
        		{
            		try {
						Thread.sleep(1000);
						DBUpdate.updateNodeVar(NID_IN_USE, GID_IN_USE, "description", text);
						view.progress();
					}  catch (InterruptedException e) { }
        		}
            }
        };
        
        this.descThread = new Thread(runnable);
        this.descThread.start();
	}
	
	public void linkCounter(String text)
	{		
		if (this.linkThread != null && this.linkThread.isAlive())
		{
			this.linkThread.interrupt();
		}
		
		Runnable runnable = new Runnable() 
		{
            @Override
            public void run() 
            {
            	if (Thread.interrupted() == false)
        		{
            		try {
						Thread.sleep(1000);
						DBUpdate.updateFileVar(NID_IN_USE, GID_IN_USE, "path", text);
						view.progress();
					}  catch (InterruptedException e) { }
        		}
            }
        };
        
        this.linkThread = new Thread(runnable);
        this.linkThread.start();
	}
	
	public void linkLabelCounter(String text)
	{		
		if (this.linkLabelThread != null && this.linkLabelThread.isAlive())
		{
			this.linkLabelThread.interrupt();
		}
		
		Runnable runnable = new Runnable() 
		{
            @Override
            public void run() 
            {
            	if (Thread.interrupted() == false)
        		{
            		try {
						Thread.sleep(1000);
						DBUpdate.updateNodeVar(NID_IN_USE, GID_IN_USE, "label", text);
						view.progress();
					}  catch (InterruptedException e) { }
        		}
            }
        };
        
        this.linkLabelThread = new Thread(runnable);
        this.linkLabelThread.start();
	}
	
	public void notesCounter()
	{		
		if (this.noteThread != null && this.noteThread.isAlive())
		{
			this.noteThread.interrupt();
		}
		
		Runnable runnable = new Runnable() 
		{
            @Override
            public void run() 
            {
            	if (Thread.interrupted() == false)
        		{
            		try {
						Thread.sleep(1000);
						DBUpdate.updateGraphNotes(GID_IN_USE, Database.clean(view.getNotesText()));
						view.progress();
					}  catch (InterruptedException e) { }
        		}
            }
        };
        
        this.noteThread = new Thread(runnable);
        this.noteThread.start();
	}
	
	public void exporter()
	{
		Exporter export = new Exporter();
        export.addNodes(DBSelect.loadNodes(GID_IN_USE));
        export.addEdges(DBSelect.loadEdges(GID_IN_USE));
        export.addFiles(DBSelect.loadFiles(GID_IN_USE));
        export.compilePDF(GID_IN_USE, NID_IN_USE);
	}
	
	public boolean nidSelected()
	{
		if (NID_IN_USE == null)
			return false;
		else
			return true;
	}
}
