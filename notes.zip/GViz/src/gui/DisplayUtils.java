package gui;

public class DisplayUtils
{

	public DisplayUtils()
	{

	}

}
