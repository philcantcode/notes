package gui;

import java.awt.Desktop;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.JComponent;

import application.Main;
import application.Settings;
import application.Settings.Key;
import database.DBInsert;
import database.DBSelect;
import database.DBUpdate;
import database.Database;
import javafx.application.Platform;
import javafx.embed.swing.SwingNode;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Accordion;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Slider;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.control.ToggleButton;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.web.HTMLEditor;
import javafx.stage.DirectoryChooser;
import structures.DBEdge;
import structures.DBFile;
import structures.DBGraph;
import structures.DBNode;
import structures.FXColour;
import structures.ShapeIcon;
import universal.CodeLogger;
import universal.CodeLogger.DEPTH;

public class DisplayController extends GraphManager implements Initializable, ActionListener
{
	@FXML private Button urlLinkBtn;				@FXML private ComboBox<String> nodeColourMenu;		
	@FXML private Button createGraphBtn;			@FXML private ComboBox<String> nodeShapeMenu;
	@FXML private Button selectFileRepoBtn;			@FXML private ComboBox<String> nodeIconMenu;
	@FXML private Button deleteGraphBtn;			@FXML private ComboBox<String> importGraphBtn;
	@FXML private Button createNodeBtn;				
	@FXML private Button deleteNodeBtn;				@FXML private Slider edgeSlider;
	@FXML private Button screenshotBtn;				@FXML private Slider paddingSlider;
	@FXML private Button exportBtn;					@FXML private Slider fontSlider;
	@FXML private Button openFileBtn;				@FXML private Slider nodeSlider;
													@FXML private Slider edgeLengthSlider;
													
	@FXML private BorderPane graphArea;				@FXML private VBox graphLoadVbox;
	@FXML private BorderPane notesArea;				@FXML private HBox dropZone;
													@FXML private VBox fileManagerVbox;
	@FXML private TextField fileManagerText;		
	@FXML private TextField currentlyLoadedGraph;	@FXML private ToggleButton showNotesBtn;
	@FXML private TextField createLabel;			@FXML private ToggleButton frozenBtn;
	@FXML private TextField selectedNode;
	@FXML private TextField fileRepoText;
	@FXML private TextField urlNameField;
													
	@FXML private Accordion menuAccord;
	@FXML private ColorPicker createColour;			@FXML private TitledPane docManager;
	@FXML private ProgressBar progressBar;
	@FXML private HTMLEditor notesEditor;
	@FXML private SplitPane graphSplitView;
	@FXML private TextArea createDesc;
	@FXML private TextArea urlLinkArea;
    
    private ArrayList<String> loadedGraphs = new ArrayList<String>();
    
    private Manager m = null;
    private boolean supressEvent = false;
    
	public DisplayController()
	{ 
		m = new Manager(this);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources)
	{
		SwingNode swingNode = new SwingNode();
		swingNode.setContent((JComponent) getGraphViewer());
		graphArea.setCenter(swingNode);	
				
		menuAccord.setExpandedPane(menuAccord.getPanes().get(2));
		createColour.setValue(javafx.scene.paint.Color.rgb(0, 0, 0));
		notesEditor.setStyle("-fx-focus-color: transparent;");
		nodeShapeMenu.setValue("Shape");
		nodeIconMenu.setValue("Icon");
		paddingSlider.setValue(Settings.getInt(Key.GRAPH_PADDING));
		fontSlider.setValue(Settings.getInt(Key.TEXT_SIZE));
		nodeSlider.setValue(Settings.getInt(Key.NODE_SIZE));
		edgeSlider.setValue(Settings.getFloat(Key.EDGE_SIZE));
		edgeLengthSlider.setValue(Settings.getInt(Key.EDGE_LENGTH));
		
		if (!Settings.getBool(Key.NOTES_VISIBLE))
    	{
    		graphSplitView.getItems().remove(1);
    		graphSplitView.setDividerPosition(0, 1);
    		showNotesBtn.fire();
    	}
		
		resetGraphMenu();
						
		createNodeBtn.setOnAction(new EventHandler<ActionEvent>() 
		{
		    @Override public void handle(ActionEvent e) 
		    {
		        String label = createLabel.getText();
		        String desc = createDesc.getText();
		        Color colour = createColour.getValue();
		        String shape = nodeShapeMenu.getValue();
		        String icon = nodeIconMenu.getValue();
		        
		        DBNode node = m.createNode(label, desc, colour, ShapeIcon.shapeDB(shape), ShapeIcon.iconDB(icon));
		        
		        if (node != null)
		        	createNode(node.nid, node.label, ShapeIcon.shapeGraph(node.shape), ShapeIcon.iconGraph(node.icon), node.colour.rgb(), false);
		        
		        resetNodeMenu();
		        
		    }
		});
		
		exportBtn.setOnAction(new EventHandler<ActionEvent>() 
		{
		    @Override public void handle(ActionEvent e) 
		    {
		        m.exporter();
		    }
		});
		
		deleteNodeBtn.setOnAction(new EventHandler<ActionEvent>() 
		{
		    @Override public void handle(ActionEvent e) 
		    {
		    	String nid = m.removeNode();
		    	
		    	if (nid != null)
		    		removeVisibleNode(nid);
		    }
		});
		
		createGraphBtn.setOnAction(new EventHandler<ActionEvent>() 
		{
		    @Override public void handle(ActionEvent e) 
		    {
		    	String label = fileManagerText.getText();
		    	DBGraph graph = m.createGraph(label);
		    	
		    	if (graph != null)
		    	{
		    		resetGraphMenu();
			    	resetGraph();
			    	
			    	currentlyLoadedGraph.setText(label);
		    	}
		    	else
		    	{
		    		DisplayController.error("Can't Create Graph", "A graph called " + label + " already exists.");
		    	}
		    }
		});
		
		deleteGraphBtn.setOnAction(new EventHandler<ActionEvent>() 
		{
		    @Override public void handle(ActionEvent e) 
		    {
		    	if (confirmation())
		    	{
		    		warning("Program Reboot", "Please reboot the application to delete the graph.");
			    	m.deleteGraph();
			    	System.exit(0);
		    	}
		    }
		});
		
		notesEditor.setOnKeyPressed(event -> 
		{
		    m.notesCounter();  
		});
		
		notesEditor.setOnKeyTyped(event -> 
		{
		    m.notesCounter();
		});
		
		createLabel.textProperty().addListener((observable, oldValue, newValue) -> 
		{
			if ((m.NID_IN_USE != null && !oldValue.equals("")) && supressEvent == false) 
			{
				m.labelCounter(newValue);
				setNodeLabel(m.NID_IN_USE, createLabel.getText());
				
				if (!openFileBtn.isDisabled())
					urlNameField.setText(createLabel.getText());
			}
		});
		
		createDesc.textProperty().addListener((observable, oldValue, newValue) -> 
		{
			if ((m.NID_IN_USE != null && !oldValue.equals("")) && supressEvent == false)
			{
				m.descCounter(createDesc.getText());
			}
		});

		nodeColourMenu.getItems().add("Red");
		nodeColourMenu.getItems().add("Green");
		nodeColourMenu.getItems().add("Blue");
		nodeColourMenu.getItems().add("Orange");
		nodeColourMenu.getItems().add("Purple");
		nodeColourMenu.getItems().add("Yellow");
		nodeColourMenu.getItems().add("Black");
				
		nodeColourMenu.setOnAction(a->
	    { 
			String colour = nodeColourMenu.getValue();
			
			if (colour.equals("Red"))
				createColour.setValue(javafx.scene.paint.Color.rgb(206,66,66));
			else if (colour.equals("Green"))
				createColour.setValue(javafx.scene.paint.Color.rgb(53,174,76));
			else if (colour.equals("Blue"))
				createColour.setValue(javafx.scene.paint.Color.rgb(51, 77, 179));
			else if (colour.equals("Orange"))
				createColour.setValue(javafx.scene.paint.Color.rgb(236,96,40));
			else if (colour.equals("Purple"))
				createColour.setValue(javafx.scene.paint.Color.rgb(142,65,158));
			else if (colour.equals("Yellow"))
				createColour.setValue(javafx.scene.paint.Color.rgb(216,202,55));
			else if (colour.equals("Black"))
				createColour.setValue(javafx.scene.paint.Color.rgb(0,0,0));
			
			if (m.NID_IN_USE != null)
			{
				FXColour col = new FXColour(createColour.getValue());
				DBUpdate.updateNodeVar(m.NID_IN_USE, m.GID_IN_USE, "colour", col.rgb());
				setNodeStyle(m.NID_IN_USE,  "fill-color: rgb(" + col.rgb() + "); ");
			}
	    });
		
		createColour.setOnAction(a ->
		{
			if (m.nidSelected() && supressEvent == false)
			{
				FXColour col = new FXColour(createColour.getValue());
				DBUpdate.updateNodeVar(m.NID_IN_USE, m.GID_IN_USE, "colour", col.rgb());
				setNodeStyle(m.NID_IN_USE,  "fill-color: rgb(" + col.rgb() + "); ");
			}
		});
		
		nodeShapeMenu.setOnAction(a ->
		{
			if (m.nidSelected() && supressEvent == false)
			{
				DBUpdate.updateNodeVar(m.NID_IN_USE, m.GID_IN_USE, "shape", ShapeIcon.shapeDB(nodeShapeMenu.getValue()));
				setNodeStyle(m.NID_IN_USE,  "shape: " + ShapeIcon.shapeGraph(nodeShapeMenu.getValue()) + "; ");
			}
		});
		
		nodeIconMenu.setOnAction(a ->
		{
			if (m.nidSelected() && supressEvent == false)
			{
				DBUpdate.updateNodeVar(m.NID_IN_USE, m.GID_IN_USE, "icon", ShapeIcon.iconDB(nodeIconMenu.getValue()));
				
				if (nodeIconMenu.getValue().equals("None"))
				{
					DBNode node = DBSelect.selectNode(m.NID_IN_USE);
					resetNodeCSS(node.nid, node.colour.rgb(), ShapeIcon.shapeGraph(node.shape), null, false);
					resetGraph();
				}
				else
					setNodeStyle(m.NID_IN_USE,  "fill-mode: image-scaled; fill-image: url('resources/icons/" + ShapeIcon.iconGraph(nodeIconMenu.getValue()) + "');");
			}
		});
		
		urlLinkArea.textProperty().addListener((observable, oldValue, newValue) -> 
		{
			if ((m.nidSelected() && supressEvent == false) && oldValue.length() != 0)
			{
				m.linkCounter(urlLinkArea.getText());
			}
		});
		
		urlNameField.textProperty().addListener((observable, oldValue, newValue) -> 
		{
			if ((m.nidSelected() && supressEvent == false) && oldValue.length() != 0)
			{
				String txt = urlNameField.getText();
				supressEvent = true;
				
				m.linkLabelCounter(txt);
				setNodeLabel(m.NID_IN_USE, txt);
				createLabel.setText(txt);
				
				supressEvent = false;
			}
		});
		
		for (String s : ShapeIcon.menuShapes())
			nodeShapeMenu.getItems().add(s);
		
		for (String s : ShapeIcon.menuIcons())
			nodeIconMenu.getItems().add(s);
		
		graphArea.setOnDragOver(new EventHandler<DragEvent>() 
		{
            @Override
            public void handle(DragEvent event) 
            {
                if (event.getGestureSource() != docManager && event.getDragboard().hasFiles()) 
                {
                    event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
                }
                
                event.consume();
            }
        });
		
		graphArea.setOnDragDropped(new EventHandler<DragEvent>() 
		{			
            @Override
            public void handle(DragEvent event) 
            {
            	if (m.GID_IN_USE == null)
            	{
            		warning("Drag & Drop", "You must select a graph in the Database Manager menu first.");
            	}
            	else if (Settings.get(Key.FILE_REPO) == null || Settings.get(Key.FILE_REPO).equals(""))
            	{
            		warning("Drag & Drop", "You must select a file repository in the Document Manger menu first.");
            	}
            	else
            	{
	                Dragboard db = event.getDragboard();
	                boolean success = false;
	                
	                CodeLogger.log("Drop detected", DEPTH.CHILD);
	                
	                if (db.hasFiles()) 
	                {
	                    for (File f : db.getFiles())
	                    {
	                		DBFile file = m.createFile(f);
	                		
	                		if (file != null)
	                		{
	                			createNode(file.node.nid, file.node.label, ShapeIcon.shapeGraph("Box"), ShapeIcon.iconGraph("Document"), 
	                					file.node.colour.rgb(), false);
	                		}
	                    }
	                    
	                    success = true;
	                }
	
	                event.setDropCompleted(success);
	                event.consume();
            	}
            }
        });		
		
		selectFileRepoBtn.setOnAction(new EventHandler<ActionEvent>() 
		{
		    @Override public void handle(ActionEvent e) 
		    {
		    	DirectoryChooser fileChooser = new DirectoryChooser();
				fileChooser.setTitle("Select File Repository");
				File f = fileChooser.showDialog(Main.stageLink);
				
				if (f != null)
				{				
					Settings.set(Key.FILE_REPO, f.getAbsolutePath());
					fileRepoText.setText(f.getName());
					DBInsert.insertSetting("FILE_REPO", f.getAbsolutePath());
				}
		    }
		});
		
		fileRepoText.setText(new File(Settings.get(Key.FILE_REPO)).getName());
		
		paddingSlider.valueProperty().addListener((observable, oldvalue, slider) ->
        {
            int i = slider.intValue();
            addGraphPadding(i);
        });
		
		paddingSlider.setOnMouseExited(evt -> 
		{
			Settings.set(Key.GRAPH_PADDING, (int) paddingSlider.getValue());
		});
		
		fontSlider.valueProperty().addListener((observable, oldvalue, slider) ->
        {
            int i = slider.intValue();
            setAllNodeStyle("text-size: " + i + ";");
        });
		
		fontSlider.setOnMouseExited(evt -> 
		{
			Settings.set(Key.TEXT_SIZE, (int) fontSlider.getValue());
		});
		
		nodeSlider.valueProperty().addListener((observable, oldvalue, slider) ->
        {
            int i = slider.intValue();
            
            if (m.NID_IN_USE != null)
            {
	            setNodeStyle(m.NID_IN_USE, "size: " + Settings.get(Key.NODE_SIZE) + "px, " + Settings.get(Key.NODE_SIZE) + "px;");
		    	m.NID_IN_USE = null;
		    	resetNodeMenu();
            }
	    	
            setAllNodeStyle("size: " + i + "px, " + i + "px;");
        });
		
		nodeSlider.setOnMouseExited(evt -> 
		{
			Settings.set(Key.NODE_SIZE, (int) nodeSlider.getValue());
		});
		
		edgeSlider.valueProperty().addListener((observable, oldvalue, slider) ->
        {
            double i = slider.doubleValue();
            setAllEdgeStyle("size: " + i + "px;");
        });
		
		edgeSlider.setOnMouseExited(evt -> 
		{
			Settings.set(Key.EDGE_SIZE, (float) edgeSlider.getValue());
		});
		
		showNotesBtn.setOnAction(new EventHandler<ActionEvent>() 
		{
		    @Override public void handle(ActionEvent e) 
		    {
		    	if (Settings.getBool(Key.NOTES_VISIBLE))
		    	{
		    		graphSplitView.getItems().remove(1);
		    		graphSplitView.setDividerPosition(0, 1);
		    		Settings.set(Key.NOTES_VISIBLE, false);
		    	}
		    	else
		    	{
		    		graphSplitView.getItems().add(notesEditor);
		    		graphSplitView.setDividerPosition(0, 0.7);
		    		Settings.set(Key.NOTES_VISIBLE, true);
		    	}
		    }
		});
		
		openFileBtn.setOnAction(new EventHandler<ActionEvent>() 
		{
		    @Override public void handle(ActionEvent e) 
		    {
		    	DBFile file = DBSelect.selectFile(m.NID_IN_USE);
		    	
		    	if (file != null)
		    	{
		    		if(Desktop.isDesktopSupported())
		    		{  
		    			Desktop desktop = Desktop.getDesktop();  
			    		File f = new File(file.path);
			    		
			    		try
						{
			    			if (file.type == DBFile.FileType.Web)
			    				desktop.browse(new URI(file.path));
			    			else
			    				desktop.open(f);
						} 
			    		catch (IOException | URISyntaxException e1)
						{
							e1.printStackTrace();
						}
		    		}  
		    	}
		    }
		});
		
		urlLinkBtn.setOnAction(new EventHandler<ActionEvent>() 
		{
		    @Override public void handle(ActionEvent e) 
		    {
		    	String url = urlLinkArea.getText();
		    	String label = urlNameField.getText();
		    	
		    	if (url.length() > 0)
		    	{
		    		DBFile f = m.createURL(url, label);
		    		createNode(f.node.nid, f.node.label, ShapeIcon.shapeGraph(f.node.shape), ShapeIcon.iconGraph(f.node.icon), f.node.colour.rgb(), false);
		    	}
		    }
		});
		
		importGraphBtn.setOnAction(a->
	    { 
			String graphLabel = importGraphBtn.getValue();
			
			if (confirmation())
			{
				m.importGraph(graphLabel);
				resetGraph();
			}
	    });
		
		edgeLengthSlider.valueProperty().addListener((observable, oldvalue, slider) ->
        {
            int i = slider.intValue();
            
            setAllEdgeAttribute("layout.weight", String.valueOf(i));
            Settings.set(Key.EDGE_LENGTH, (int) edgeLengthSlider.getValue());
            resetGraph();
        });
	}
	
	public void resetGraphMenu()
	{		
		importGraphBtn.getItems().clear();
		
		for (DBGraph g : DBSelect.loadGraphs())
		{
			if (!loadedGraphs.contains(g.label))
			{
				Button fileLoadButton = new Button(g.label);
				fileLoadButton.setMaxWidth(Integer.MAX_VALUE);
				graphLoadVbox.getChildren().add(fileLoadButton);
				
				fileLoadButton.setOnAction(new EventHandler<ActionEvent>() 
				{
				    @Override public void handle(ActionEvent e) 
				    {
				    	resetGraphMenu();
				    	currentlyLoadedGraph.setText(g.label);
				    	m.GID_IN_USE = g.gid;
				    	importGraphBtn.getItems().remove(loadedGraphs.indexOf(g.label));
				    	resetGraph();
				    }
				});
			}
			
			if (!loadedGraphs.contains(g.label))
				loadedGraphs.add(g.label);
			
			importGraphBtn.getItems().add(g.label);
		}
	}
	
	public void resetGraph()
	{
		progress();
		clearView();
		initGraphAttributes();
		resetNodeMenu();
		
		notesEditor.setHtmlText("");
		notesEditor.setHtmlText(DBSelect.selectGraph(m.GID_IN_USE).notes);
    	notesEditor.setDisable(false);
    	createNodeBtn.setDisable(false);
    	deleteNodeBtn.setDisable(false);
    	deleteGraphBtn.setDisable(false);
    	screenshotBtn.setDisable(false);
    	exportBtn.setDisable(false);
    	urlLinkArea.setDisable(false);
    	urlLinkBtn.setDisable(false);
    	urlNameField.setDisable(false);
    	importGraphBtn.setDisable(false);
		
		for (DBNode node : DBSelect.loadNodes(m.GID_IN_USE))
		{			
			createNode(node.nid, node.label, ShapeIcon.shapeGraph(node.shape), ShapeIcon.iconGraph(node.icon), node.colour.rgb(), false);
		}
    	
    	for (DBEdge edge : DBSelect.loadEdges(m.GID_IN_USE))
    	{
    		addEdge(edge.eid, edge.src, edge.dst, edge.label);
    	}
	}
	
	public void resetNodeMenu()
	{
		m.NID_IN_USE = null;
		selectedNode.clear();
    	createLabel.clear();
    	createDesc.clear();
    	urlLinkArea.clear();
    	urlNameField.clear();
    	openFileBtn.setDisable(true);
	}
	
	public void addEdge(String eid, String src, String dst, String label)
	{
		if (edgeExists(eid) == false && (nodeExists(src) && nodeExists(dst)))
		{
			createEdge(eid, src, dst, label);
			setEdgeStyle(eid, "size: " + Settings.get(Key.EDGE_SIZE) + ";");
		}
	}
	
	@Override
	public void mouseClicked(MouseEvent e)
	{
		int x = e.getX();
    	int y = e.getY();
    	
    	try 
    	{
    	    String destNID = findNodeAt(x, y);    	    
    	    menuAccord.setExpandedPane(menuAccord.getPanes().get(0));
    	    
    	    if (m.NID_IN_USE == null)
    	    {
    	    	m.NID_IN_USE = destNID;
    	    	setNodeStyle(destNID, "size: " + (Settings.getInt(Key.NODE_SIZE) + 10) + "px, " + (Settings.getInt(Key.NODE_SIZE) + 10) + "px;");
       	    	selectedNode.setText(destNID);
   	
       	    	Platform.runLater(new Runnable()
       	    	{
       	    		DBNode node = DBSelect.selectNode(m.NID_IN_USE);
       	    		DBFile file = DBSelect.selectFile(m.NID_IN_USE);
	       	    	
					@Override
					public void run()
					{
						supressEvent = true;
						
						createLabel.setText(node.label);
		       	    	createDesc.setText(node.description);
						createColour.setValue(node.colour.fx());	
						nodeIconMenu.setValue(node.icon);
						nodeShapeMenu.setValue(node.shape);
						
						supressEvent = false;
						
						if (file != null)
						{
							openFileBtn.setDisable(false);
							urlLinkArea.setText(file.path);
							urlNameField.setText(node.label);
						}
					}       	    	
       	    	});
      
    	    }
    	    else if (m.NID_IN_USE.equals(destNID))
    	    {
    	    	setNodeStyle(m.NID_IN_USE, "size: " + Settings.get(Key.NODE_SIZE) + "px, " + Settings.get(Key.NODE_SIZE) + "px;");
    	    	m.NID_IN_USE = null;
    	    	resetNodeMenu();
    	    }
    	    else
    	    {
    	    	DBEdge edge = m.toggleEdge(m.NID_IN_USE, destNID, "");
    	    	
    	    	if (edge.deleted == true)
    	    		removeEdge(edge.eid);
    	    	else
	    	    	addEdge(edge.eid, edge.src, edge.dst, "");
    	    	
    	    	setNodeStyle(m.NID_IN_USE, "size: " + Settings.get(Key.NODE_SIZE) + "px, " + Settings.get(Key.NODE_SIZE) + "px;");
    	    	resetNodeMenu();
    	    }
    	}
    	catch (NullPointerException ne)
    	{
    		if (m.NID_IN_USE != null)
    		{
    			setNodeStyle(m.NID_IN_USE, "size: " + Settings.get(Key.NODE_SIZE) + "px, " + Settings.get(Key.NODE_SIZE) + "px;");
		    	m.NID_IN_USE = null;
		    	resetNodeMenu();
    		}
    	}
		
	}
	
	public void progress()
	{
		Runnable runnable = new Runnable() 
		{
            @Override
            public void run() 
            {
            	for (double i = 0.1; i <= 1; i += 0.1)
        		{
        			progressBar.setProgress(i);
        			
        			try
        			{
        				Thread.sleep(100);
        			} 
        			catch (InterruptedException e)
        			{
        				e.printStackTrace();
        			}
        			
        			progressBar.setProgress(0);
        		}
            }
        };
        
        new Thread(runnable).start();
	}
	
	public static void warning(String title, String info)
	{
		Alert alert = new Alert(AlertType.WARNING);
		alert.setTitle("Cannot Complete Action");
		alert.setHeaderText(title);
		alert.setContentText(info);
		alert.showAndWait();
	}
	
	public static void error(String title, String info)
	{
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("Cannot Complete Action");
		alert.setHeaderText(title);
		alert.setContentText(info);
		alert.showAndWait();
	}
	
	public static boolean confirmation()
	{
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Are you sure?");

		ButtonData bd = alert.showAndWait().get().getButtonData();
		
		if (bd.isCancelButton())
			return false;
		else
			return true;
	}
	
	public String getNotesText()
	{
		return notesEditor.getHtmlText();
	}
	
	@Override public void actionPerformed(java.awt.event.ActionEvent e) { }
}
