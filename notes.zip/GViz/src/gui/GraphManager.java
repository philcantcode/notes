package gui;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import org.graphstream.graph.Edge;
import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.view.View;
import org.graphstream.ui.view.Viewer;

import application.Settings;
import application.Settings.Key;

public class GraphManager implements MouseListener, MouseWheelListener
{
	private static Graph graph;
    private static Viewer viewer;
    private static View view;
	
	public GraphManager()
	{		
		graph = new SingleGraph("main");
		
		viewer = new Viewer(graph, Viewer.ThreadingModel.GRAPH_IN_ANOTHER_THREAD);
        view = viewer.addDefaultView(false);
        view.addMouseListener(this);
        viewer.enableAutoLayout();  
        initGraphAttributes();
   	}
	
	public void initGraphAttributes()
	{
		graph.addAttribute("ui.antialias", true);
        graph.addAttribute("ui.quality", true);
        graph.addAttribute("layout.quality", 4);
        //graph.addAttribute("layout.stabilization-limit", 50);
        graph.addAttribute("layout.frozen", false);
        graph.addAttribute("ui.stylesheet", "graph { fill-color: rgb(71, 71, 71); padding: " + Settings.get(Key.GRAPH_PADDING) + "; }"); 
	}
	
	public void removeVisibleNode(String id)
	{
		graph.removeNode(id);
	}
	
	public void addGraphPadding(int amount)
	{
		graph.addAttribute("ui.stylesheet", "graph { padding: " + amount + "; }");  
	}
	
	public View getGraphViewer()
	{
		return view;
	}
	
	public void clearView()
	{
		graph.clear();
	}
	
	public boolean nodeExists(String nid)
	{
		if (graph.getNode(nid) == null)
			return false;
		else
			return true;
	}
	
	public boolean edgeExists(String eid)
	{
		if (graph.getEdge(eid) == null)
			return false;
		else
			return true;
	}
	
	public void createNode(String nid, String label, String shape, String icon, String colour, boolean bigger)
	{
		if (nodeExists(nid) == false)
		{
			String css = generateNodeCSS(colour, shape, icon, bigger);
			
			graph.addNode(nid);
					
			if (label != null)
				graph.getNode(nid).setAttribute("ui.label", label);	 
			
			if (css != null)
				graph.getNode(nid).setAttribute("ui.style", css);
		}
	}
	
	public void createEdge(String eid, String src, String dst, String label)
	{
		graph.addEdge(eid, src, dst, true);
		graph.getEdge(eid).addAttribute("layout.weight", Settings.get(Key.EDGE_LENGTH));
		
		if (label != null)
		{
			graph.getEdge(eid).setAttribute("ui.label", label);	
			graph.getEdge(eid).setAttribute("ui.style", "fill-color: rgb(255,255,255);");
		}
	}
	
	public String findNodeAt(int x, int y)
	{
		return view.findNodeOrSpriteAt(x, y).getId();
	}
	
	public void setNodeStyle(String nid, String css)
	{
		graph.getNode(nid).setAttribute("ui.style", css);
	}
	
	public void setAllNodeStyle(String css)
	{
		for (Node n : graph.getNodeSet())
		{
			graph.getNode(n.getId()).setAttribute("ui.style", css);
		}
	}
	
	public void setEdgeStyle(String eid, String css)
	{
		graph.getEdge(eid).setAttribute("ui.style", css);
	}
	
	public void setAllEdgeStyle(String css)
	{
		for (Edge e : graph.getEdgeSet())
		{
			graph.getEdge(e.getId()).setAttribute("ui.style", css);
		}
	}
	
	public void setAllEdgeAttribute(String attr, String val)
	{
		for (Edge e : graph.getEdgeSet())
		{
			graph.getEdge(e.getId()).setAttribute(attr, val);
		}
	}
	
	public void removeEdge(String eid)
	{
		graph.removeEdge(eid);	
	}
	
	public void setNodeLabel(String nid, String label)
	{
		graph.getNode(nid).setAttribute("ui.label", label);
	}
	
	public void resetNodeCSS(String nid, String colour, String shape, String icon, boolean bigger)
	{
		String css = generateNodeCSS(colour, shape, icon, bigger);
		
		graph.getNode(nid).removeAttribute("ui.style");
		setNodeStyle(nid, css);
	}
	
	public String generateNodeCSS(String colour, String shape, String icon, boolean bigger)
	{
		String css = "";
		
		int nodeSize = Settings.getInt(Key.NODE_SIZE);
		
		if (bigger)
			nodeSize += 10;
		
		if (icon == null)
		{
			css += "text-size: " + Settings.get(Key.TEXT_SIZE) + "; ";
			css += "shape: " + shape + "; ";
			css += "size: " + nodeSize + "px, " + nodeSize + "px; ";
			css += "fill-color: rgb(" + colour + "); ";
			css += "text-color: rgb(255,255,255); ";
			css += "text-alignment: at-right; ";
		}
		else
		{	
			css += "text-size: " + Settings.get(Key.TEXT_SIZE) + "; ";
			css += "shape: box; ";
			css += "fill-mode: image-scaled; ";
			css += "fill-image: url('resources/icons/" + icon + "'); ";
			css += "size: " + nodeSize + "px, " + nodeSize + "px; ";
			css += "text-color: rgb(255,255,255); ";
			css += "text-alignment: at-right; ";
		}
		
		return css;
	}

	@Override public void mousePressed(MouseEvent e) { }
	@Override public void mouseReleased(MouseEvent e) { }
	@Override public void mouseEntered(MouseEvent e) { }
	@Override public void mouseExited(MouseEvent e) { }
	@Override public void mouseClicked(MouseEvent e) { }

	@Override
	public void mouseWheelMoved(MouseWheelEvent e)
	{
		
	}

}
