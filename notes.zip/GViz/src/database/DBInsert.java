package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import universal.CodeLogger;
import universal.CodeLogger.DEPTH;

public class DBInsert
{
	protected static Connection c = null;
	protected static PreparedStatement stmt = null;
	protected static ResultSet rs = null;
	
	public DBInsert()
	{
		c = Database.c;
		stmt = Database.stmt;
		rs = Database.rs;
	}
	
	public static boolean insertNode(String nid, String gid, String label, String desc, String colour, String shape, String icon)
	{
		label = Database.clean(label);
		desc = Database.clean(desc);
		
	    try {
	         stmt = c.prepareStatement("INSERT INTO `nodes` (nid, gid, label, description, colour, shape, icon) VALUES (?, ?, ?, ?, ?, ?, ?)");
	         stmt.setString(1, nid);
	         stmt.setString(2, gid);
	         stmt.setString(3, label);
	         stmt.setString(4, desc);
	         stmt.setString(5, colour);
	         stmt.setString(6, shape);
	         stmt.setString(7, icon);
	         
	         stmt.executeUpdate();

	         stmt.close();
	         c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	CodeLogger.log(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    	return false;
	    }
	    
	    CodeLogger.log("Insert Node Successful", DEPTH.CHILD);
	    return true;
	}
	
	public static boolean insertEdge(String eid, String gid, String label, String src, String dst)
	{
		label = Database.clean(label);
		
	    try {
	         stmt = c.prepareStatement("INSERT INTO `edges` (eid, gid, label, src, dst) VALUES (?, ?, ?, ?, ?);");
	         stmt.setString(1, eid);
	         stmt.setString(2, gid);
	         stmt.setString(3, label);
	         stmt.setString(4, src);
	         stmt.setString(5, dst);
	         
	         stmt.executeUpdate();

	         stmt.close();
	         c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	CodeLogger.log(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    	return false;
	    }
	    
	    CodeLogger.log("Insert Edge Successful", DEPTH.CHILD);
	    return true;
	}
	
	public static boolean insertGraph(String gid, String label, String description)
	{
		label = Database.clean(label);
		description = Database.clean(description);
		
		try {
	         stmt = c.prepareStatement("INSERT INTO `graphs` (gid, label, description) VALUES (?, ?, ?);");
	         stmt.setString(1, gid);
	         stmt.setString(2, label);
	         stmt.setString(3, description);
	         
	         stmt.executeUpdate();

	         stmt.close();
	         c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	CodeLogger.log(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    	return false;
	    }
		
		CodeLogger.log("Insert Graph Successful", DEPTH.CHILD);
		return true;
	}
	
	public static void insertSetting(String key, String value)
	{	
		try {
	         stmt = c.prepareStatement("INSERT INTO `settings` (key, value) VALUES (?, ?);");
	         stmt.setString(1, key);
	         stmt.setString(2, value);
	         
	         stmt.executeUpdate();

	         stmt.close();
	         c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
		
		CodeLogger.log("Insert Setting Successful", DEPTH.CHILD);
	}
	
	public static void insertFile(String nid, String gid, String hash, String type, String path)
	{	
		try {
	         stmt = c.prepareStatement("INSERT INTO `files` (nid, gid, hash, type, path) VALUES (?, ?, ?, ?, ?);");
	         stmt.setString(1, nid);
	         stmt.setString(2, gid);
	         stmt.setString(3, hash);
	         stmt.setString(4, type);
	         stmt.setString(5, path);
	         
	         stmt.executeUpdate();

	         stmt.close();
	         c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
		
		CodeLogger.log("Insert File Successful", DEPTH.CHILD);
	}
}
