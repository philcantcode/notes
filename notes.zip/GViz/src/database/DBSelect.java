package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import application.Settings;
import structures.DBEdge;
import structures.DBFile;
import structures.DBGraph;
import structures.DBNode;
import structures.FXColour;
import universal.CodeLogger;
import universal.CodeLogger.DEPTH;

public class DBSelect
{
	protected static Connection c = null;
	protected static PreparedStatement ps = null;
	protected static ResultSet rs = null;
	
	public DBSelect()
	{
		c = Database.c;
		ps = Database.stmt;
		rs = Database.rs;
	}
	
	public static ArrayList<DBNode> loadNodes(String gid)
	{
		ArrayList<DBNode> nodes = new ArrayList<DBNode>();
		
		try {
	         ps = c.prepareStatement("SELECT * FROM `nodes` WHERE gid = ?;");
	         ps.setString(1, gid);
	         
	         rs = ps.executeQuery();
	         
	         while (rs.next()) 
	         {
	        	 DBNode n = new DBNode(rs.getString("nid"), rs.getString("gid"), rs.getString("label"), 
	        			 rs.getString("description"), new FXColour(rs.getString("colour")), rs.getString("shape"), rs.getString("icon"));
	        	
	        	 nodes.add(n);
	         }

	         ps.close();
	         c.commit(); 
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
		
		CodeLogger.log("Select Nodes Successful", DEPTH.CHILD);
		
		return nodes;
	}
	
	public static ArrayList<DBEdge> loadEdges(String gid)
	{		
		ArrayList<DBEdge> edges = new ArrayList<DBEdge>();
		
		try {
	         ps = c.prepareStatement("SELECT * FROM `edges` WHERE gid = ?;");
	         ps.setString(1, gid);
	         rs = ps.executeQuery();
	         
	         while (rs.next()) 
	         {
	        	DBEdge e = new DBEdge(rs.getString("eid"), rs.getString("gid"), 
	        			rs.getString("label"), rs.getString("src"), rs.getString("dst"));
	        	edges.add(e);	        	
	         }

	         ps.close();
	         c.commit(); 
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
		
		CodeLogger.log("Select Edges Successful", DEPTH.CHILD);
		
		return edges;
	}
	
	public static ArrayList<DBGraph> loadGraphs()
	{
		ArrayList<DBGraph> graphs = new ArrayList<DBGraph>();
		
		try {
	         ps = c.prepareStatement("SELECT * FROM `graphs` ORDER BY `label` ASC;");
	         rs = ps.executeQuery();
	         
	         while (rs.next()) 
	         {
	        	 DBGraph g = new DBGraph(rs.getString("gid"), rs.getString("label"), rs.getString("notes"), rs.getString("description"));
	        	 graphs.add(g);
	         }

	         ps.close();
	         c.commit(); 
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
		
		CodeLogger.log("Select Graphs Successful", DEPTH.CHILD);
		
		return graphs;
	}
	
	public static ArrayList<DBGraph> loadSettings()
	{
		ArrayList<DBGraph> graphs = new ArrayList<DBGraph>();
		
		try {
	         ps = c.prepareStatement("SELECT * FROM `settings`;");
	         rs = ps.executeQuery();
	         
	         while (rs.next()) 
	         {
	        	 Settings.settings.put(Settings.mapKey(rs.getString("key")), rs.getString("value"));
	         }

	         ps.close();
	         c.commit(); 
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
		
		CodeLogger.log("Select Settings Successful", DEPTH.CHILD);
		
		return graphs;
	}
	
	public static ArrayList<DBFile> loadFiles(String gid)
	{
		ArrayList<DBFile> files = new ArrayList<DBFile>();
		
		try {
	         ps = c.prepareStatement("SELECT * FROM `files` WHERE gid = ?;");
	         ps.setString(1, gid);
	         rs = ps.executeQuery();
	         
	         while (rs.next()) 
	         {
	        	 DBFile g = new DBFile(rs.getString("nid"), rs.getString("gid"),
	        			 rs.getString("path"), rs.getString("hash"), DBFile.getType(rs.getString("type")));
	        	 
	        	 files.add(g);
	         }

	         ps.close();
	         c.commit(); 
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
		
		CodeLogger.log("Select Files Successful", DEPTH.CHILD);
		
		return files;
	}
	
	public static DBNode selectNode(String nid)
	{				
		try {
			ps = c.prepareStatement("SELECT * FROM `nodes` WHERE nid = ?;");
			ps.setString(1, nid);
	         
	        rs = ps.executeQuery();
	         
	        while (rs.next()) 
	        {
	        	CodeLogger.log("Select Node Successful", DEPTH.CHILD);
	        	 
	        	return new DBNode(rs.getString("nid"), rs.getString("gid"), rs.getString("label"), 
	        			rs.getString("description"), new FXColour(rs.getString("colour")), rs.getString("shape"), rs.getString("icon"));
	        }

	        ps.close();
	        c.commit(); 
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
				
		return null;
	}
	
	public static DBEdge selectEdge(String eid)
	{				
		try {
			ps = c.prepareStatement("SELECT * FROM `edges` WHERE eid = ?;");
	        ps.setString(1, eid); 
			rs = ps.executeQuery();
			 
			while (rs.next()) 
			{
				CodeLogger.log("Select Edge Successful", DEPTH.CHILD);

				return new DBEdge(rs.getString("eid"), rs.getString("gid"), 
						rs.getString("label"), rs.getString("src"), rs.getString("dst"));
			}
			
			ps.close();
			c.commit(); 
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
				
		return null;
	}
	
	public static DBGraph selectGraph(String gid)
	{				
		try {
			ps = c.prepareStatement("SELECT * FROM `graphs` WHERE gid = ?;");
			ps.setString(1, gid);
	         
	        rs = ps.executeQuery();
	         
	        while (rs.next()) 
	        {
	        	CodeLogger.log("Select Graph Successful", DEPTH.CHILD);
	        	 
	        	return new DBGraph(rs.getString("gid"), rs.getString("label"), rs.getString("notes"), rs.getString("description"));
	        }

	        ps.close();
	        c.commit(); 
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
				
		return null;
	}
	
	public static DBGraph selectGraphByLabel(String label)
	{				
		try {
			ps = c.prepareStatement("SELECT * FROM `graphs` WHERE label = ?;");
			ps.setString(1, label);
	         
	        rs = ps.executeQuery();
	         
	        while (rs.next()) 
	        {
	        	CodeLogger.log("Select Graph Successful", DEPTH.CHILD);
	        	 
	        	return new DBGraph(rs.getString("gid"), rs.getString("label"), rs.getString("notes"), rs.getString("description"));
	        }

	        ps.close();
	        c.commit(); 
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
				
		return null;
	}
	
	public static DBFile selectFile(String fid)
	{				
		try {
			ps = c.prepareStatement("SELECT * FROM `files` WHERE nid = ?;");
			ps.setString(1, fid);
	         
	        rs = ps.executeQuery();
	         
	        while (rs.next()) 
	        {
	        	CodeLogger.log("Select File Successful", DEPTH.CHILD);
	        	 
	        	return new DBFile(rs.getString("nid"), rs.getString("gid"), 
	        			rs.getString("path"), rs.getString("hash"), DBFile.getType(rs.getString("type")));
	        }

	        ps.close();
	        c.commit(); 
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
				
		return null;
	}
}
