package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import universal.CodeLogger;
import universal.CodeLogger.DEPTH;

public class DBDelete
{
	protected static Connection c = null;
	protected static PreparedStatement stmt = null;
	protected static ResultSet rs = null;
	
	public DBDelete()
	{
		c = Database.c;
		stmt = Database.stmt;
		rs = Database.rs;
	}
	
	public static void deleteNode(String nid, String gid)
	{		
	    try {
	         stmt = c.prepareStatement("DELETE FROM `nodes` WHERE nid = ? AND gid = ?;");
	         stmt.setString(1, nid);
	         stmt.setString(2, gid);
	         
	         stmt.executeUpdate();

	         stmt.close();
	         c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
	    
	    CodeLogger.log("Delete Node Successful", DEPTH.CHILD);
	}
	
	public static void deleteEdge(String eid, String gid)
	{
	    try {
	         stmt = c.prepareStatement("DELETE FROM `edges` WHERE eid = ? AND gid = ?;");
	         stmt.setString(1, eid);
	         stmt.setString(2, gid);
	         
	         stmt.executeUpdate();

	         stmt.close();
	         c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
	    
	    CodeLogger.log("Delete Edge Successful", DEPTH.CHILD);
	}
	
	public static void deleteEdgeByLink(String nid, String gid)
	{
	    try {
	         stmt = c.prepareStatement("DELETE FROM `edges` WHERE (src = ? OR dst = ?) AND gid = ?;");
	         stmt.setString(1, nid);
	         stmt.setString(2, nid);
	         stmt.setString(3, gid);
	         
	         stmt.executeUpdate();

	         stmt.close();
	         c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
	    
	    CodeLogger.log("Delete Edge Successful", DEPTH.CHILD);
	}
	
	public static void deleteGraph(String gid)
	{
		try {
	         stmt = c.prepareStatement("DELETE FROM `graphs` WHERE gid = ?;");
	         stmt.setString(1, gid);
	         
	         stmt.executeUpdate();

	         stmt.close();
	         c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
		
		CodeLogger.log("Delete Graph Successful", DEPTH.CHILD);
	}
	
	public static void deleteSetting(String key)
	{
		try {
	         stmt = c.prepareStatement("DELETE FROM `settings` WHERE key = ?;");
	         stmt.setString(1, key);
	         
	         stmt.executeUpdate();

	         stmt.close();
	         c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
		
		CodeLogger.log("Delete Setting Successful", DEPTH.CHILD);
	}
	
	public static void deleteFile(String nid, String gid)
	{		
	    try {
	         stmt = c.prepareStatement("DELETE FROM `files` WHERE nid = ? AND gid = ?;");
	         stmt.setString(1, nid);
	         stmt.setString(2, gid);
	         
	         stmt.executeUpdate();

	         stmt.close();
	         c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
	    
	    CodeLogger.log("Delete File Successful", DEPTH.CHILD);
	}
}
