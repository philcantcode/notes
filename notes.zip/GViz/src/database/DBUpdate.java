package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import universal.CodeLogger;
import universal.CodeLogger.DEPTH;

public class DBUpdate
{
	protected static Connection c = null;
	protected static PreparedStatement stmt = null;
	protected static ResultSet rs = null;
	
	public DBUpdate()
	{
		c = Database.c;
		stmt = Database.stmt;
		rs = Database.rs;
	}
	
	public static void updateNode(String nid, String gid, String label, String description, String colour, String shape, String icon)
	{
		label = Database.clean(label);
		description = Database.clean(description);
		
		try {
			stmt = c.prepareStatement("UPDATE `nodes` SET label = ?, description = ?, colour = ?, shape = ?, icon = ? WHERE nid = ? AND gid = ?;");
			stmt.setString(1, label);
			stmt.setString(2, description);
			stmt.setString(3, colour);
			stmt.setString(4, shape);
			stmt.setString(5, icon);
			stmt.setString(6, nid);
			stmt.setString(7, gid);
	         
			stmt.executeUpdate();

			stmt.close();
			c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
		
		CodeLogger.log("Update Node Successful", DEPTH.CHILD);
	}
	
	public static void updateNodeVar(String nid, String gid, String column, String value)
	{
		try {
			stmt = c.prepareStatement("UPDATE `nodes` SET " + column + " = ? WHERE nid = ? AND gid = ?;");
			stmt.setString(1, value);
			stmt.setString(2, nid);
			stmt.setString(3, gid);
	         
			stmt.executeUpdate();

			stmt.close();
			c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err("Update Node Var error", DEPTH.ROOT);
	    }
		
		CodeLogger.log("Update Node Variable Successful (" + column + ": " + value + ")", DEPTH.CHILD);
	}
	
	public static void updateGraphNotes(String gid, String notes)
	{
		notes = Database.clean(notes);
		
		try {
			stmt = c.prepareStatement("UPDATE `graphs` SET notes = ? WHERE gid = ?;");
	        stmt.setString(1, notes);
	        stmt.setString(2, gid);
	        
	        stmt.executeUpdate();

	        stmt.close();
	        c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
		
		CodeLogger.log("Update Graph Notes Successful", DEPTH.CHILD);
	}
	
	public static void updateFileVar(String nid, String gid, String column, String value)
	{
		try {
			stmt = c.prepareStatement("UPDATE `files` SET " + column + " = ? WHERE nid = ? AND gid = ?;");
			stmt.setString(1, value);
			stmt.setString(2, nid);
			stmt.setString(3, gid);
	         
			stmt.executeUpdate();

			stmt.close();
			c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	e.printStackTrace();
	    	CodeLogger.err("Update File Var error", DEPTH.ROOT);
	    }
		
		CodeLogger.log("Update File Variable Successful (" + column + ": " + value + ")", DEPTH.CHILD);
	}
	
	public static void updateSettings(String key, String value)
	{
		try {
			stmt = c.prepareStatement("UPDATE `settings` SET value = ? WHERE key = ?;");
			stmt.setString(1, value);
			stmt.setString(2, key);
	         
			stmt.executeUpdate();

			stmt.close();
			c.commit();
	    } 
	    catch ( Exception e ) 
	    {
	    	CodeLogger.err(e.getClass().getName() + ": " + e.getMessage(), DEPTH.ROOT);
	    }
		
		CodeLogger.log("Update Setting Successful (" + key + ")", DEPTH.CHILD);
	}

}
